## 1b. Causas de colapso por nivel y algoritmo

| nivel | algoritmo | causa_colapso | corridas |
|---|---|---|---|
| ALTA | AG | llegada tardía (a bordo) | 5 |
| ALTA | AG | llegada tardía (planificada) | 13 |
| ALTA | TABU | llegada tardía (a bordo) | 6 |
| ALTA | TABU | llegada tardía (planificada) | 12 |
| BAJA | AG | llegada tardía (a bordo) | 1 |
| BAJA | TABU | llegada tardía (a bordo) | 3 |
| BAJA | TABU | llegada tardía (planificada) | 2 |
| MEDIA | AG | llegada tardía (planificada) | 9 |
| MEDIA | TABU | llegada tardía (a bordo) | 5 |
| MEDIA | TABU | llegada tardía (planificada) | 5 |
