## 1b. Causas de colapso por nivel y algoritmo

| nivel | algoritmo | causa_colapso | corridas |
|---|---|---|---|
| ALTA | AG | destino bloqueado | 7 |
| ALTA | AG | llegada tardía (a bordo) | 7 |
| ALTA | AG | llegada tardía (planificada) | 8 |
| ALTA | TABU | destino bloqueado | 6 |
| ALTA | TABU | llegada tardía (a bordo) | 6 |
| ALTA | TABU | llegada tardía (planificada) | 12 |
| BAJA | AG | destino bloqueado | 9 |
| BAJA | AG | llegada tardía (a bordo) | 2 |
| BAJA | AG | llegada tardía (planificada) | 2 |
| BAJA | TABU | destino bloqueado | 9 |
| BAJA | TABU | llegada tardía (planificada) | 1 |
| MEDIA | AG | destino bloqueado | 5 |
| MEDIA | AG | llegada tardía (a bordo) | 4 |
| MEDIA | AG | llegada tardía (planificada) | 8 |
| MEDIA | TABU | destino bloqueado | 5 |
| MEDIA | TABU | llegada tardía (a bordo) | 2 |
| MEDIA | TABU | llegada tardía (planificada) | 3 |
